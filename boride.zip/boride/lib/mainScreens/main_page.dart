import 'dart:async';

import 'package:boride/assistants/geofire_assistant.dart';
import 'package:boride/brand_colors.dart';
import 'package:boride/models/active_nearby_available_drivers.dart';
import 'package:boride/widgets/brand_divider.dart';
import 'package:boride/widgets/my_drawer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ionicons/ionicons.dart';


class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final Completer<GoogleMapController> _controllerGoogleMap = Completer();

  final Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? mapController;

  GlobalKey<ScaffoldState> sKey = GlobalKey<ScaffoldState>();
  double searchLocationContainerHeight = 220;
  bool openNavigationDrawer = true;

  Set<Marker> markersSet = {};
  Set<Circle> circlesSet = {};

  bool activeNearbyDriverKeysLoaded = false;
  BitmapDescriptor? activeNearbyIcon;

  List<LatLng> pLineCoOrdinatesList = [];
  Set<Polyline> polyLineSet = {};


  List<ActiveNearbyAvailableDrivers> onlineNearByAvailableDriversList = [];

  var geoLocator = Geolocator();
  Position? currentPosition;


  double bottomPaddingOfMap = 0;

  locateUserPosition() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;

    LatLng latLngPosition =
    LatLng(currentPosition!.latitude, currentPosition!.longitude);
    CameraPosition cp = CameraPosition(target: latLngPosition, zoom: 15);
    initializeGeoFireListener();
    mapController!
        .animateCamera(CameraUpdate.newCameraPosition(cp));

  }



  static const CameraPosition _kBorideHq = CameraPosition(
    target: LatLng(9.074329, 7.507098),
    zoom: 14,
  );

  initializeGeoFireListener() {
    Geofire.initialize("activeDrivers");

    Geofire.queryAtLocation(
        currentPosition!.latitude, currentPosition!.longitude, 10)!
        .listen((map) {
      print(map);
      if (map != null) {
        var callBack = map['callBack'];

        //latitude will be retrieved from map['latitude']
        //longitude will be retrieved from map['longitude']

        switch (callBack) {
        //whenever any driver become active/online
          case Geofire.onKeyEntered:
            ActiveNearbyAvailableDrivers activeNearbyAvailableDriver =
            ActiveNearbyAvailableDrivers();
            activeNearbyAvailableDriver.locationLatitude = map['latitude'];
            activeNearbyAvailableDriver.locationLongitude = map['longitude'];
            activeNearbyAvailableDriver.driverId = map['key'];
            GeoFireAssistant.activeNearbyAvailableDriversList
                .add(activeNearbyAvailableDriver);
            if (activeNearbyDriverKeysLoaded == true) {
              displayActiveDriversOnUsersMap();
            }
            break;

        //whenever any driver become non-active/offline
          case Geofire.onKeyExited:
            GeoFireAssistant.deleteOfflineDriverFromList(map['key']);
            displayActiveDriversOnUsersMap();
            break;

        //whenever driver moves - update driver location
          case Geofire.onKeyMoved:
            ActiveNearbyAvailableDrivers activeNearbyAvailableDriver =
            ActiveNearbyAvailableDrivers();
            activeNearbyAvailableDriver.locationLatitude = map['latitude'];
            activeNearbyAvailableDriver.locationLongitude = map['longitude'];
            activeNearbyAvailableDriver.driverId = map['key'];
            GeoFireAssistant.updateActiveNearbyAvailableDriverLocation(
                activeNearbyAvailableDriver);
            displayActiveDriversOnUsersMap();
            break;

        //display those online/active drivers on user's map
          case Geofire.onGeoQueryReady:
            activeNearbyDriverKeysLoaded = true;
            displayActiveDriversOnUsersMap();
            break;
        }
      }

      setState(() {});
    });
  }


  displayActiveDriversOnUsersMap() {
    setState(() {
      markersSet.clear();
      circlesSet.clear();

      Set<Marker> driversMarkerSet = Set<Marker>();

      for (ActiveNearbyAvailableDrivers eachDriver
      in GeoFireAssistant.activeNearbyAvailableDriversList) {
        LatLng eachDriverActivePosition =
        LatLng(eachDriver.locationLatitude!, eachDriver.locationLongitude!);

        Marker marker = Marker(
          markerId: MarkerId("driver" + eachDriver.driverId!),
          position: eachDriverActivePosition,
          icon: activeNearbyIcon!,
          rotation: 360,
        );

        driversMarkerSet.add(marker);
      }

      setState(() {
        markersSet = driversMarkerSet;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    createActiveNearByDriverIconMarker();
    return Scaffold(
        key: sKey,
        drawer: SizedBox(
          width: 265,
          child: Theme(
            data: Theme.of(context).copyWith(
              canvasColor: Colors.white,
            ),
            child: MyDrawer(
              name: "userName",
              email: "userEmail",
            ),
          ),
        ),
        body: Stack(
          children: [
            GoogleMap(
              padding: EdgeInsets.only(bottom: bottomPaddingOfMap),
              mapType: MapType.normal,
              myLocationEnabled: true,
              zoomGesturesEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              minMaxZoomPreference: const MinMaxZoomPreference(10, 16),
              initialCameraPosition: _kBorideHq,
              polylines: polyLineSet,
              markers: markersSet,
              circles: circlesSet,
              onMapCreated: (GoogleMapController controller) {
                _controllerGoogleMap.complete(controller);
                mapController = controller;

                //for black theme google map

                setState(() {
                  bottomPaddingOfMap = 270;
                });

                locateUserPosition();
              },
            ),
            //custom hamburger button for drawer
            Positioned(
              top: 30,
              left: 14,
              child: GestureDetector(
                onTap: () {
                  if (openNavigationDrawer) {
                    sKey.currentState!.openDrawer();
                  } else {
                    //restart-refresh-minimize app progmatically
                    SystemNavigator.pop();
                  }
                },
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(
                    openNavigationDrawer ? Ionicons.menu : Ionicons.close,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 270,
              right: 14,
              child: GestureDetector(
                onTap: () {
                  locateUserPosition();

                  LatLng latLngPosition = LatLng(currentPosition!.latitude,
                      currentPosition!.longitude);

                  CameraPosition cameraPosition =
                  CameraPosition(target: latLngPosition, zoom: 16);

                  mapController!.animateCamera(
                      CameraUpdate.newCameraPosition(cameraPosition));
                },
                child: const CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(
                    Ionicons.locate_outline,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                height: MediaQuery.of(context).size.height * 0.35,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 5,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7))
                    ]),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24.0, vertical: 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 5,
                      ),
                      const Text("Nice to see you",
                          style: TextStyle(fontSize: 10)),
                      const Text("Where are you going",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Brand-Bold')),
                      const SizedBox(
                        height: 20,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: const [
                              BoxShadow(
                                  blurRadius: 4,
                                  spreadRadius: 0.1,
                                  offset: Offset(0.7, 0.7))
                            ]),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Row(
                            children: const [
                              Icon(
                                Icons.search,
                                color: Colors.blueAccent,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                "Search",
                                style: TextStyle(color: Colors.grey),
                              )
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 30,),
                      Row(
                        children:  [
                          const Icon(Ionicons.home_outline, color: Colors.black54,),
                          const SizedBox(width: 12,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text("Add Home", style: TextStyle(fontSize: 11, color: Colors.black, fontWeight: FontWeight.bold)),
                              SizedBox(height: 3,),
                              Text("Your residential address", style: TextStyle(fontSize: 11, color: BrandColors.colorDimText),)],
                          )
                        ],
                      ),
                      const SizedBox(height: 10,),
                      const BrandDivider(),
                      const SizedBox(height: 16,),
                      Row(
                        children:  [
                          const Icon(Ionicons.briefcase, color: Colors.black54,),
                          const SizedBox(width: 12,),
                          Column(crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text("Add works", style: TextStyle(fontSize: 11, color: Colors.black, fontWeight: FontWeight.bold)),
                              SizedBox(height: 3,),
                              Text("Your residential address", style: TextStyle(fontSize: 11, color: BrandColors.colorDimText),)],
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            )
          ],
        )
    );
  }
  createActiveNearByDriverIconMarker() {
    if (activeNearbyIcon == null) {
      ImageConfiguration imageConfiguration =
      createLocalImageConfiguration(context, size: const Size(2, 2));
      BitmapDescriptor.fromAssetImage(imageConfiguration, "images/car3.png")
          .then((value) {
        activeNearbyIcon = value;
      });
    }
  }
}
