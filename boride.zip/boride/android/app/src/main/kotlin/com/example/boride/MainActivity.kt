package com.example.boride

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
